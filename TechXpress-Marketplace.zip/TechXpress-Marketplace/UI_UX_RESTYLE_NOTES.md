# TechXpress Marketplace — UI/UX Restyle Notes

This package is the **Buyonic** full-stack codebase with its **UI/UX reskinned to the
TechXpress visual identity** from the DEPI final project design mockups
(`Picturt Design/*.png`). No business logic was changed — every `.ts` file
(components, services, guards, interceptors, models, routing) and the entire
`Backend/` solution are untouched. Only presentation-layer files were edited:
`.html` templates, `.scss`/`.css` stylesheets, and `index.html` metadata.

## What changed

**Design tokens (`Frontend/Buyonic/src/styles.scss`)**
The whole app previously ran on a single dark purple/violet theme (`--primary:
#6c63ff` on `--bg-primary: #0f0f1a`). The token set was replaced with the
TechXpress palette sampled from the DEPI mockups:

- `--primary` → warm orange `#f2641a` (was indigo/violet)
- `--accent` → amber/gold `#ffb347` (was pink)
- `--bg-primary` → white (storefront/dashboards are now light, matching the
  checkout, profile, browse, and approvals mockups)
- `--bg-card` → soft peach `#fbeae0` (matches the peach card surfaces seen
  throughout the mockups)
- New tokens: `--bg-ink` / `--text-on-dark` / `--text-on-dark-muted` /
  `--border-dark` for the dark "chrome" surfaces (navbar, footer, admin
  sidebar, auth pages), and `--bg-soft` for subtle neutral panels (table
  headers, pills, icon backdrops) that previously relied on the
  now-repurposed `--bg-secondary`.

Because the original codebase already used CSS variables consistently
(confirmed by audit — only ~20 files had any hardcoded color), this single
token rewrite cascades through almost every component automatically.

**Dark chrome components** (navbar, footer, admin sidebar, the 4 auth pages)
keep their dark backgrounds as in the mockups, with text colors switched to
the new `--text-on-dark` / `--text-on-dark-muted` tokens so contrast still
works now that the global text tokens flipped to dark-on-light.

**Rebranding** — "Buyonic" → "TechXpress" and the 🛒 icon → ⚡ in the navbar,
footer, all 4 auth screens, the admin sidebar label, and `index.html`
title/meta. (Internal, non-UI identifiers like `decodeBuyonicToken()` were
intentionally left alone since they're logic, not UI.)

**Other small fixes**: a few literal toast/badge colors that hardcoded the
old purple were swapped to the new palette and re-checked for contrast; the
unused default-Angular-CLI placeholder markup in `app.html` (dead code never
rendered — `app.ts` uses its own inline template) was tidied up.

## Verified

`npm install && ng build --configuration development` completes with no
errors. (A production build will also succeed once it has normal internet
access — the only production-build error in this sandbox was Angular's
font-inlining step being blocked from reaching `fonts.googleapis.com`, not a
code issue.)

## Not changed

- `Backend/` — entire .NET solution, untouched.
- All `.ts` logic: services, guards, interceptors, models, routing.
- Page copy/content and component structure/markup hierarchy (only colors,
  typography tokens, branding strings, and a couple of contrast-driven class
  swaps were edited).
